package com.example.metadatacleaner

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.itextpdf.text.pdf.PdfReader
import com.itextpdf.text.pdf.PdfStamper
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var selectButton: Button
    private lateinit var cleanButton: Button
    private lateinit var resultText: TextView
    private var selectedUri: Uri? = null
    private val PICK_FILE_REQUEST = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        selectButton = findViewById(R.id.select_button)
        cleanButton = findViewById(R.id.clean_button)
        resultText = findViewById(R.id.result_text)

        selectButton.setOnClickListener { selectFile() }
        cleanButton.setOnClickListener { cleanMetadata() }
        cleanButton.isEnabled = false
    }

    private fun selectFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(Intent.createChooser(intent, "Selecciona un archivo"), PICK_FILE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                selectedUri = uri
                resultText.text = "Archivo seleccionado: ${uri.path}"
                cleanButton.isEnabled = true
            }
        }
    }

    private fun cleanMetadata() {
        selectedUri?.let { uri ->
            val outputDir = File(getExternalFilesDir(null), "cleaned_files")
            if (!outputDir.exists()) outputDir.mkdirs()

            val fileName = getFileName(uri) ?: "cleaned_file"
            val extension = fileName.substringAfterLast(".", "")
            val outputPath = "$outputDir/${fileName.substringBeforeLast(".")}_cleaned.$extension"

            when (extension.lowercase()) {
                "jpg", "jpeg", "png" -> cleanImageMetadata(uri, outputPath)
                "pdf" -> cleanPdfMetadata(uri, outputPath)
                else -> {
                    Toast.makeText(this, "Formato no soportado: $extension", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            resultText.text = "Archivo limpio guardado en: $outputPath"
            Toast.makeText(this, "Metadatos eliminados con éxito", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cleanImageMetadata(uri: Uri, outputPath: String) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            bitmap?.compress(Bitmap.CompressFormat.JPEG, 100, FileOutputStream(outputPath))
                ?: Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_SHORT).show()
            inputStream?.close()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al procesar imagen: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun cleanPdfMetadata(uri: Uri, outputPath: String) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            if (inputStream == null) {
                Toast.makeText(this, "No se pudo abrir el archivo PDF", Toast.LENGTH_LONG).show()
                return
            }
            val reader = PdfReader(inputStream)
            val stamper = PdfStamper(reader, FileOutputStream(outputPath))
            stamper.setMoreInfo(HashMap<String, String>()) // Elimina metadatos con un diccionario vacío
            stamper.close()
            reader.close()
            inputStream.close()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al procesar PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun getFileName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            cursor.moveToFirst()
            return cursor.getString(nameIndex)
        }
        return null
    }
}
